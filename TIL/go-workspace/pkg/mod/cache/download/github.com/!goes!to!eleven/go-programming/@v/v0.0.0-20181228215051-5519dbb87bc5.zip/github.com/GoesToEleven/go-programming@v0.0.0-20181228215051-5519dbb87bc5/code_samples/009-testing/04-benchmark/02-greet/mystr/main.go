package mystr

import "fmt"

func Greet(s string) string {
	return fmt.Sprint("Hello my dear, ", s)
}
