package cat

import "fmt"

func Hello() {
	fmt.Println("Hello from cat")
}

func Eats() {
	fmt.Println("Cat eats birds")
}
