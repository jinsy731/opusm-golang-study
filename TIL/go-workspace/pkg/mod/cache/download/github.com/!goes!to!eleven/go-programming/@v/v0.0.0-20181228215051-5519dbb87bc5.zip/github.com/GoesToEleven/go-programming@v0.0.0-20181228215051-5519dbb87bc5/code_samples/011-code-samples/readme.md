This code is not covered in a video lecture.

The code in this folder provides examples of code I like.

This code has been provided so that you can look at it and learn from it.

To learn more about Go programming, come join my "Go Web Dev" course!

:)
