package acdc

import "fmt"

func ExampleSum() {
	fmt.Println(Sum(2, 3))
	// Output:
	// 5
}
