package main

import (
	"fmt"
	"github.com/GoesToEleven/go-programming/code_samples/009-testing/04-benchmark/02-greet/mystr"
)

func main() {
	fmt.Println(mystr.Greet("James"))
}
