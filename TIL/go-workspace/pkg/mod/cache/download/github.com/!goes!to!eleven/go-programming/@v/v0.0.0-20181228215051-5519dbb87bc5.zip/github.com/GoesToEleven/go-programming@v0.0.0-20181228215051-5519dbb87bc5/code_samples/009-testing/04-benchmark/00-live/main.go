package main

import (
	"fmt"
	"github.com/GoesToEleven/go-programming/code_samples/009-testing/04-benchmark/00-live/saying"
)

func main() {
	fmt.Println(saying.Greet("James"))
}
