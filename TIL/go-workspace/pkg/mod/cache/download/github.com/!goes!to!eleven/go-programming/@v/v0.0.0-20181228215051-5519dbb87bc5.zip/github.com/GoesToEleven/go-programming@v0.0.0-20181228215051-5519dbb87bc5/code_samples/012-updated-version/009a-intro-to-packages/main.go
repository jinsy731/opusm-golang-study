package main

import "fmt"

func main() {
	n, _ := fmt.Println("Hello, playground", 42, true)
	fmt.Println(n)
}
